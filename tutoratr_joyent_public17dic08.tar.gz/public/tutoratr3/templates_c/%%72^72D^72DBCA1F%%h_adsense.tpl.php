<?php /* Smarty version 2.6.18, created on 2007-12-15 19:08:55
         compiled from h_adsense.tpl */ ?>
<div style="text-align: center; width: 400px; filter: chroma (color=#FFFFFF);">
	<script type="text/javascript"><!--
	google_ad_client = "pub-8824615395440396";
	//234x60, para fb
	google_ad_slot = "6578925434";
	google_ad_width = 234;
	google_ad_height = 60;
	//--></script>
	<script type="text/javascript"
	src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>
</div>