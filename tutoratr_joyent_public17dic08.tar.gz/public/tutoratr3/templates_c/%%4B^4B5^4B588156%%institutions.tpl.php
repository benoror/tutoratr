<?php /* Smarty version 2.6.18, created on 2008-12-09 00:23:56
         compiled from institutions.tpl */ ?>
<!---<span class="inst_barc"><a href="javascript:;" onclick="openRecent();" >ITESM</a></span>
<span class="inst_bar"><a href="javascript:;" onclick="openInstitution();" >UDEM</a></span>
<span class="inst_bar"><a href="javascript:;" onclick="openInstitution();" >UANL</a></span>--->
<blink><b>Ayudanos con nuestros anuncios patrocinadores!</b></blink>
<span class="inst_bar"><a href="http://www.tutoratr.com">www.tutoratr.com</a></span>
<!---</b></div>--->