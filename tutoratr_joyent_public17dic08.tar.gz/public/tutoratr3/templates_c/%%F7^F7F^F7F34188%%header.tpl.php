<?php /* Smarty version 2.6.18, created on 2007-12-17 08:49:25
         compiled from header.tpl */ ?>

<div class="logo"><a href="javascript:window.location=window.location;"><img src="images/logo3.png" /></a></div>
<div id="navigator">
    <ul class="main_set">
        <li><a href="javascript:;" onclick="openRecent();" title="Nuevos">
        		<img src="images/recent.png" />
        </a></li>
        <li><a href="javascript:;" onclick="openAdd();" title="Agregar">
		        <img src="images/add_big.png" />
        </a></li>
        <li><a href="javascript:;" onclick="openTop10();" title="Top 10">
        		<img src="images/excel.png" />
        </a></li>
        <li><a href="javascript:;" onclick="openForum();" title="Foro">
        		<img src="images/forum.png" />
        </a></li>
        <li><a href="javascript:;" onclick="openHelp();" title="Ayuda">
        		<img src="images/help.png" />
        </a></li>
    </ul>
</div>