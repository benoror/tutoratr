<?php /* Smarty version 2.6.18, created on 2008-12-09 00:26:15
         compiled from leftcolumn.tpl */ ?>
<div style="text-align: center;">
Si esta web ha sido &uacute;til para ti, ayudanos:<br/><br />
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_donations">
<input type="hidden" name="business" value="CUX8M2G29Q92E">
<input type="hidden" name="lc" value="MX">
<input type="hidden" name="item_name" value="Tutoratr">
<input type="hidden" name="item_number" value="TUTORATR01">
<input type="hidden" name="currency_code" value="MXN">
<input type="hidden" name="bn" value="PP-DonationsBF:btn_donate_LG.gif:NonHosted">
<input type="image" src="https://www.paypal.com/es_XC/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="">
<img alt="" border="0" src="https://www.paypal.com/es_XC/i/scr/pixel.gif" width="1" height="1">
</form>

</div>
<br />

<h2 style="text-align: center;">Busqueda</h2>
<input type="text" id="search_text" class="inputtext inputsearch" value="" />

<br /><br />
<div style="text-align: center;">
	<span class="inst_barc">
	<a href="javascript:openSearch($('#search_text').val());">Buscar</a>
	</span>
</div>

<br />
<a href="http://www.facebook.com/add.php?api_key=4ba14807f76b6a844c0ad9c430ea1328">
	<img src="images/fb.gif" />
	Facebook
</a>
<br />
<a href="http://feeds.feedburner.com/Tutoratr-UltimosComentarios">
	<img src="images/rss.gif" />
	RSS
</a>