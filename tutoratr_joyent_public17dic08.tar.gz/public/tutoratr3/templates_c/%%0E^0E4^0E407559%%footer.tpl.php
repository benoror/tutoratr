<?php /* Smarty version 2.6.18, created on 2007-12-15 19:08:55
         compiled from footer.tpl */ ?>
<p align="center" class="bottoma">
	(C) 2007 Tutoratr<br />
	Powered by <a href="http://en.wikipedia.org/wiki/LAMP_(software_bundle)">LAMP</a>,
	<a href="http://smarty.php.net/">Smarty engine</a>,
	<a href="http://en.wikipedia.org/wiki/AJAX">AJAX</a>.<br />
	thx2 <a href="http://www.raptadoporaliens.com">raptadoporaliens.com</a>
</p>