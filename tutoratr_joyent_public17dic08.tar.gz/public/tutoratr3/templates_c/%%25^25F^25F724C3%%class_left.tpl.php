<?php /* Smarty version 2.6.18, created on 2007-12-15 19:10:21
         compiled from class_left.tpl */ ?>
<div style="text-align:center">
<h4>-</h4>
</div>