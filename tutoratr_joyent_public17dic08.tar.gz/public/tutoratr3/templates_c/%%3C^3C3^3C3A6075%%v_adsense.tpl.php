<?php /* Smarty version 2.6.18, created on 2007-12-15 19:08:55
         compiled from v_adsense.tpl */ ?>
<script type="text/javascript"><!--
	google_ad_client = "pub-8824615395440396";
	google_alternate_color = "e9e9e9";
	google_ad_width = 160;
	google_ad_height = 600;
	google_ad_format = "160x600_as";
	google_ad_type = "text";
	//2007-07-17: RightBar
	google_ad_channel = "1844862395";
	google_color_border = "FFFFFF";
	google_color_bg = "FFFFFF";
	google_color_link = "3b5998";
	google_color_text = "555555";
	google_color_url = "cccccc";
	google_ui_features = "rc:0";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>