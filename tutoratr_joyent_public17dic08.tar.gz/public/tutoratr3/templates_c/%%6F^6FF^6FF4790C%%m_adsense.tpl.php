<?php /* Smarty version 2.6.18, created on 2007-12-15 19:11:26
         compiled from m_adsense.tpl */ ?>
<div style="text-align: center; width: 400px; filter: chroma (color=#FFFFFF);">
	<script type="text/javascript"><!--
	google_ad_client = "pub-8824615395440396";
	//468x15, middle
	google_ad_slot = "4880727730";
	google_ad_width = 410;
	google_ad_height = 15;
	//--></script>
	<script type="text/javascript"
	src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>
</div>