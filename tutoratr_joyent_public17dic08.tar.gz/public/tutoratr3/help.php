<div style="background: url(images/help.png) no-repeat;" class="title_sec">
Ayuda
</div>
<br />
<p>
Ésta página web fue creada con la intención de hacer valer el derecho de todo estudiante a expresar su opinion con criterio y responsabilidad. No es el propósito de ésta página web el ser utilizada como medio de ofensa o desprestigio.
</p>
<br />
<p>
Ésta pagina web guarda la dirección IP y la fecha y hora exacta en que un mensaje fue enviado con motivos de monitoreo y seguridad. Al hacer uso de la misma se aceptan éstos términos y condiciones voluntariamente.
</p>
<br />
<p>
Al hacer uso de éste servicio el usuario debe aceptar que no le dará usos difamatorios, malintencionados, vulgares, abusivos, obscenos, con contenido sexual explícito u algún otro contenido que viole la privacidad de terceros.
</p>
<br />
<p>
Considerando la naturaleza interactiva en tiempo real de éste servicio es imposible para el personal revisar TODOS los mensajes o confirmar la validez de los mismos. Debido a esto, el personal no se hace responsable por el contenido de los mensajes publicados, ésta recae en los autores de los mismos.
</p>
<br />
<p>
Cada mensaje representa el punto de vista del individuo que lo publica sin tener relación alguna con la opinión del personal de éste servicio. Cualquier usuario que piense que un mensaje viola cualquiera de los postulados anteriores se le pide que exprese su queja inmediatamente vía <a href="mailto:tutoratr@gmail.com">email</a> o en el <a href="javascript:;" onclick="openForum()">foro</a> para una revisión.
</p>
<br />
<p>
El personal de éste servicio se reserva el derecho de eliminar cualquier mensaje que no cumpla con los anteriores postulados y se compromete a esforzarse en lograr éste objetivo.
</p>
<br />
<p>
Atte.: El personal de tutoratr
