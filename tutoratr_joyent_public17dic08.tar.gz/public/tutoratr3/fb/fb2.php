<br />
<fb:tabs>
	<fb:tab-item href="http://apps.facebook.com/tutoratr/fb3.php" title="Tutoratr 3" />
	<fb:tab-item href="http://apps.facebook.com/tutoratr/fb2.php" title="Tutoratr 2" selected="true"/>
	<fb:tab-item href="http://tutoratr.wordpress.com" title="Blog" />
	<fb:tab-item href="http://apps.facebook.com/tutoratr/index.php" title="Invita a tus amigos" />
</fb:tabs>

<fb:iframe src="http://d91440c2.fb.joyent.us/tutoratr2/index.php" smartsize="true" frameborder="0" />
