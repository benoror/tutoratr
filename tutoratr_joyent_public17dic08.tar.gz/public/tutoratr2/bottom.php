
<!-- AJAX DIV ENDS -->
</div>

	</div>
		 <!-- End Left Column -->
		 
		 <!-- Begin Right Column -->
		 <div id="rightcolumn">
		 

<?php include('last_added.php'); ?>

		 <div id="sbar" align="center">
		    <p>¡Ahora puedes agregar la aplicacion a <b>Facebook</b>!</p><br />
		 	<span id="fbbar">
		 	<a href="http://www.facebook.com/add.php?api_key=4ba14807f76b6a844c0ad9c430ea1328">&nbsp;&nbsp;Agregar a Facebook</a>
		 	</span>
		 </div>
		 <br />

<script type="text/javascript"><!--
google_ad_client = "pub-8824615395440396";
google_alternate_color = "e9e9e9";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text";
//2007-07-17: RightBar
google_ad_channel = "1844862395";
google_color_border = "FFFFFF";
google_color_bg = "FFFFFF";
google_color_link = "3b5998";
google_color_text = "555555";
google_color_url = "cccccc";
google_ui_features = "rc:0";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
		 
		 </div>
		 <!-- End Right Column -->
		 
		 <!-- Begin Footer -->
		 <div id="footer">
		       
			   <p align="center" class="bottoma">
			   	(C) 2007 Tutoratr<br />
			   	Powered by <a href="http://en.wikipedia.org/wiki/LAMP_(software_bundle)">LAMP</a><br />
			   	thx2 <a href="http://www.raptadoporaliens.com">raptadoporaliens.com</a>
			   </p>	
			    
	     </div>
		 <!-- End Footer -->
		 
   </div>
   <!-- End Wrapper -->
   
</body>
</html>
