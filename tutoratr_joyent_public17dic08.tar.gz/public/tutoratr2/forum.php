<div style="background: url(images/forum.png) no-repeat;" class="title_sec">
Foro
</div>

<iframe src="http://tutoratr.awardspace.com/mlf/" width="100%" height="540px" style="border: 1px solid #ccc;"></iframe>
